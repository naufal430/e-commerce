<script>
  $(document).ready(function(){
   $(".dropdown_header").click(function(){
     $(this).find(".dropdown_menu_header").slideToggle("fast");
   });
   
  });
  </script>