<?php
session_start();

include("functions/functions.php");

include("includes/db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/style.css">
    <script src="../js/jquery-3.4.1.js"></script>
    <title>Mondstadt - Your Trusted Shop</title>
</head>
<body>
    <div class="main-wrapper">
        <div class="header-wrapper">
            <div class="header-logo">
                <a href="index.php">
                    <img id="logo" src="images/logotoko1.png" />
                </a>
            </div>

            <div id="form">
                <form method="get" action="results.php" enctype="multipart/form-data">
                    <input type="text" name="user_query" placeholder="Search a Product" />
	                <input type="submit" name="search" value="Search" />
                </form>
            </div>

            <?php if(!isset($_SESSION['user_id'])){ ?>
                <div class="register-login">
                    <div class="login">
                        <a href="index.php?action=login">Login</a>
                    </div>
                    
                    <div class="register">
                        <a href="register.php">Register</a>
                    </div>
                </div>
            <?php } else { ?>
                <?php
                    $select_user = mysqli_query($conn,"SELECT * FROM users WHERE id='$_SESSION[user_id] '");
                    $data_user = mysqli_fetch_array($select_user);
                ?>

                <div id="profile">
                    <ul>
                        <li>
                            <a>
                                <?php if($data_user['image'] !=''){ ?>
                                    <span><img src="uploaded-files/<?php echo $data_user['image']; ?>"></span>
                                <?php } else { ?>
                                    <span><img src="images/profile-icon.png"></span>
                                <?php } ?>
                            </a>

                            <ul class="dropdown-menu-header">
                                <li>
                                    <a href="my_account.php?action=edit_account">Account Setting</a>
                                </li>
                                <li>
                                    <a href="logout.php">Logout</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            <?php } ?>
        </div>