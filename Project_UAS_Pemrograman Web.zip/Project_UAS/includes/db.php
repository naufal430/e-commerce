<?php

$conn = mysqli_connect("localhost","root","","db_project_uts");

if(mysqli_connect_errno()){
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

mysqli_query($conn,"SET NAMES 'utf8' ");

?>