        <div id="footer">
            <h2 style="text-align:center; padding-top:30px">&copy; 2020 Mondstadt Store</h2>
        </div>
    </div>
</body>

</html>