

    <div class="form_box">

	 <form action="" method="post" enctype="multipart/form-data">
	   
	   <table align="center" width="100%">
	     
		 <tr>
		   <td colspan="7">
		   <h2>Tambah Kategori</h2>
		   <div class="border_bottom"></div>
		   </td>
		 </tr>
		 
		 <tr>
		   <td><b>Tambah Kategori Baru:</b></td>
		   <td><input type="text" name="kategori_produk" size="60" required/></td>
		 </tr>	 
		
		<tr>
		   <td></td>
		   <td colspan="7"><input type="submit" name="insert_cat" value="Add Category"/></td>
		</tr>
	   </table>
	   
	 </form>
	 
  </div>

<?php 

if(isset($_POST['insert_cat'])){   
   
   $product_cat = mysqli_real_escape_string($conn,$_POST['kategori_produk']);
   
   $insert_cat = mysqli_query($conn,"insert into kategori (judul_kategori) values ('$product_cat') ");
   
   if($insert_cat){
    echo "<script>alert('Product category has been inserted successfully!')</script>";
	
	echo "<script>window.open(window.location.href,'_self')</script>";
   }
   
   }
?>








