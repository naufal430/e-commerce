

    <div class="form_box">

	 <form action="" method="post" enctype="multipart/form-data">
	   
	   <table align="center" width="100%">
	     
		 <tr>
		   <td colspan="7">
		   <h2>Tambah Merk</h2>
		   <div class="border_bottom"></div>
		   </td>
		 </tr>
		 
		 <tr>
		   <td><b>Tambah Merk Baru:</b></td>
		   <td><input type="text" name="judul_brand" size="60" required/></td>
		 </tr>	 
		
		<tr>
		   <td></td>
		   <td colspan="7"><input type="submit" name="insert_brand" value="Add Brand"/></td>
		</tr>
	   </table>
	   
	 </form>
	 
  </div>

<?php 

if(isset($_POST['insert_brand'])){   
   
   $product_brand = mysqli_real_escape_string($conn,$_POST['judul_brand']);
   
   $insert_brand = mysqli_query($conn,"insert into brands (judul_brand) values ('$product_brand') ");
   
   if($insert_brand){
    echo "<script>alert('Product brand has been inserted successfully!')</script>";
	
	echo "<script>window.open(window.location.href,'_self')</script>";
   }
   
   }
?>








