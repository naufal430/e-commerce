
<?php 
$edit_brand = mysqli_query($conn,"select * from brands where brand_id='$_GET[brand_id]'");

$fetch_brand = mysqli_fetch_array($edit_brand);

?>


    <div class="form_box">

	 <form action="" method="post" enctype="multipart/form-data">
	   
	   <table align="center" width="100%">
	     
		 <tr>
		   <td colspan="7">
		   <h2>Edit Merk</h2>
		   <div class="border_bottom"></div>
		   </td>
		 </tr>
		 
		 <tr>
		   <td><b>Edit Kategori:</b></td>
		   <td><input type="text" name="merk_produk" value="<?php echo $fetch_brand['judul_brand']; ?>" size="60" required/></td>
		 </tr>	 
		
		<tr>
		   <td></td>
		   <td colspan="7"><input type="submit" name="edit_brand" value="Save"/></td>
		</tr>
	   </table>
	   
	 </form>
	 
  </div>

<?php 

if(isset($_POST['edit_brand'])){   
   
   $brand_title = mysqli_real_escape_string($conn,$_POST['product_brand']);
   
   $edit_brand = mysqli_query($conn,"update brands set judul_brand='$brand_title' where brand_id='$_GET[brand_id]'");
   
   if($edit_brand){
    echo "<script>alert('Merk Produk sudah di Update')</script>";
	
	echo "<script>window.open(window.location.href,'_self')</script>";
   }
   
   }
?>








