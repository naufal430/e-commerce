
<?php 
$edit_cat = mysqli_query($conn,"select * from kategori where id_kategori='$_GET[cat_id]'");

$fetch_cat = mysqli_fetch_array($edit_cat);

?>


    <div class="form_box">

	 <form action="" method="post" enctype="multipart/form-data">
	   
	   <table align="center" width="100%">
	     
		 <tr>
		   <td colspan="7">
		   <h2>Edit Kategori</h2>
		   <div class="border_bottom"></div>
		   </td>
		 </tr>
		 
		 <tr>
		   <td><b>Edit Kategori:</b></td>
		   <td><input type="text" name="kategori_produk" value="<?php echo $fetch_cat['judul_kategori']; ?>" size="60" required/></td>
		 </tr>	 
		
		<tr>
		   <td></td>
		   <td colspan="7"><input type="submit" name="edit_cat" value="Save"/></td>
		</tr>
	   </table>
	   
	 </form>
	 
  </div>

<?php 

if(isset($_POST['edit_cat'])){   
   
   $cat_title = mysqli_real_escape_string($conn,$_POST['kategori_produk']);
   
   $edit_cat = mysqli_query($conn,"update kategori set judul_kategori='$cat_title' where id_kategori='$_GET[cat_id]'");
   
   if($edit_cat){
    echo "<script>alert('Product category was updated successfully!')</script>";
	
	echo "<script>window.open(window.location.href,'_self')</script>";
   }
   
   }
?>








