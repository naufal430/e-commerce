

<div class="view_product_box">

<h2>Lihat Produk</h2>
<div class="border_bottom"></div>

<form action="" method="post" enctype="multipart/form-data" />

<div class="search_bar">
  <input type="text" id="search" placeholder="Type to search..." />
</div>

<table width="100%">
 <thead>
  <tr>
   <th><input type="checkbox" id="checkAll" />Check</th>
   <th>ID</th>
   <th>Judul</th>
   <th>Harga</th>
   <th>Image</th>
   <th>Views</th>
   <th>Date</th>
   <th>Status</th>
   <th>Delete</th>
   <th>Edit</th>
  </tr>
 </thead>

 
 <?php 
 $all_products = mysqli_query($conn,"select * from produk order by id_produk DESC ");
 
 $i = 1;
 
 while($row=mysqli_fetch_array($all_products)){
 ?>
 
 <tbody>
  <tr>
   <td><input type="checkbox" name="deleteAll[]" value="<?php echo $row['id_produk'];?>" /></td>
   <td><?php echo $i; ?></td>
   <td><?php echo $row['judul_produk']; ?></td>
   <td><?php echo $row['harga_produk']; ?></td>
   <td><img src="images_produk/<?php echo $row['image_produk']; ?>" width="70" height="50" /></td>
   <td><?php echo $row['views']; ?></td>
   <td><?php echo $row['date']; ?></td>
   <td>
   <?php 
   if($row['visible'] == 1){
    echo "Approved";
   }else{
    echo "Pending";
   }
   ?>
   </td>
   <td><a href="index.php?action=view_pro&delete_product=<?php echo $row['id_produk'];?>">Delete</a></td>
   <td><a href="index.php?action=edit_pro&id_produk=<?php echo $row['id_produk'];?>">Edit</a></td>
  </tr>
 </tbody>
 
 <?php $i++;}?>
 
<tr>
<td><input type="submit" name="delete_all" value="Remove" /></td>
<td><a target="_blank" href="includes/export_xls.php" id="export-xls">Export ke xls</a></td>
<td><a target="_blank" href="includes/export_pdf.php" id="export-pdf">Export ke pdf</a></td>
</tr> 
</table>

</form>

</div>


<?php


if(isset($_GET['delete_product'])){
  $delete_product = mysqli_query($conn,"delete from produk where id_produk='$_GET[delete_product]' ");
  
  if($delete_product){
  echo "<script>alert('Product has been deleted successfully!')</script>";
  
  echo "<script>window.open('index.php?action=view_pro','_self')</script>";
  
  }
}


if(isset($_POST['deleteAll'])){
  $remove = $_POST['deleteAll'];
  
  foreach($remove as $key){
  $run_remove = mysqli_query($conn,"delete from produk where id_produk='$key'");
  
  if($run_remove){
  echo "<script>alert('Items selected have been removed successfully!')</script>";
  
  echo "<script>window.open('index.php?action=view_pro','_self')</script>";
  }else{
  echo "<script>alert('Mysqli Failed: mysqli_error($conn)!')</script>";
  }
  }
}
 ?>



