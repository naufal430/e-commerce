

<?php 
$edit_product = mysqli_query($conn,"select * from products where product_id='$_GET[product_id]' ");

$fetch_edit = mysqli_fetch_array($edit_product);
?>

    <div class="form_box">

	 <form action="" method="post" enctype="multipart/form-data">
	   
	   <table align="center" width="100%">
	     
		 <tr>
		   <td colspan="7">
		   <h2>Edit Produk</h2>
		   <div class="border_bottom"></div>
		   </td>
		 </tr>
		 
		 <tr>
		   <td><b>Judul Produk:</b></td>
		   <td><input type="text" name="judul_produk" value="<?php echo $fetch_edit['judul_produk'];  ?>" size="60" required/></td>
		 </tr>
		 
		 <tr>
		   <td><b>Kategori:</b></td>
		   <td>
		    <select name="kategori_produk">
			  <option>Pilih Kategori</option>
			  
			  <?php 
			  $get_cats ="select * from kategori";
		
		$run_cats = mysqli_query($conn, $get_cats);
		
		while($row_cats=mysqli_fetch_array($run_cats)){
		    $cat_id = $row_cats['id_kategori'];
			
			$cat_title = $row_cats['judul_kategori'];
			
			if($fetch_edit['kategori_produk'] == $cat_id){
			echo "<option value='$fetch_edit[kategori_produk]' selected>$cat_title</option>";
			
			}else{
			echo "<option value='$cat_id'>$cat_title</option>";
			
			}
		}
			  ?>
			</select>
		   </td>
		   
		 </tr>
		 
		 <tr>
		   <td><b>Merk Produk:</b></td>
		   <td>
		    <select name="merk_produk">
			  <option>Pilih Merk</option>
			<?php
			  $get_brands = "select * from brands";
		
		$run_brands = mysqli_query($conn, $get_brands);
		
		while($row_brands = mysqli_fetch_array($run_brands)){
		     $brand_id = $row_brands['brand_id'];
			 
			 $brand_title = $row_brands['judul_brand'];
			 
			 if($fetch_edit['product_brand'] == $brand_id){
			 echo "<option value='$fetch_edit[merk_produk]' selected>$brand_title</option>";
			 
			 }else{			 
			 echo "<option value='$brand_id'>$brand_title</option>";
			 
			 }
		}
		
		?>
			</select>
		   </td>
		   
		 </tr>
		
        <tr>
		  <td valign="top"><b>Image Produk: </b></td>
		  <td>
		  <input type="file" name="image_produk" />
		  <div class="edit_image">
		   <img src="images_produk/<?php echo $fetch_edit['image_produk']; ?>" width="100" height="70" />
		  </div>
		  </td>
		</tr>
		
		<tr>
		  <td><b>Harga Produk: </b></td>
		  <td><input type="text" name="harga_produk" value="<?php echo $fetch_edit['harga_produk']; ?>" required/></td>
		</tr>
		
		<tr>
		   <td valign="top"><b>Deksripsi Produk:</b></td>
		   <td><textarea name="desc_produk"  rows="10"><?php echo $fetch_edit['desc_produk'];?></textarea></td>
		</tr>
		
		
		<tr>
		  <td><b>Keywords Produk: </b></td>
		  <td><input type="text" name="keywords_produk" value="<?php echo $fetch_edit['keywords_produk'];?>" required/></td>
		</tr>
		
		<tr>
		   <td></td>
		   <td colspan="7"><input type="submit" name="edit_product" value="Save"/></td>
		</tr>
	   </table>
	   
	 </form>
	 
  </div><!-- /.form_box -->

<?php 

if(isset($_POST['edit_product'])){
   $product_title = trim(mysqli_real_escape_string($conn,$_POST['judul_produk']));
   $product_cat = $_POST['kategori_produk'];
   $product_brand = $_POST['merk_produk'];
   $product_price = $_POST['harga_produk'];
   $product_desc = trim(mysqli_real_escape_string($conn,$_POST['desc_produk']));
   $product_keywords = $_POST['keywords_produk']; 
   $date = date("F d, Y");
   
   $product_image  = $_FILES['image_produk']['name'];
   $product_image_tmp = $_FILES['image_produk']['tmp_name'];
   
   if(!empty($_FILES['image_produk']['name'])){
   
   if(move_uploaded_file($product_image_tmp,"images_produk/$product_image")){
   
   $update_product = mysqli_query($conn,"update products set kategori_produk='$product_cat', merk_produk='$product_brand', judul_produk='$product_title', harga_produk='$product_price', desc_produk='$product_desc',image_produk='$product_image',keywords_produk='$product_keywords',date='$date' where id_produk='$_GET[id_produk]' ");
   
   }
   
   }else{
   $update_product = mysqli_query($conn,"update products set kategori_produk='$product_cat', merk_produk='$product_brand', judul_produk='$product_title', harga_produk='$product_price', desc_produk='$product_desc',keywords_produk='$product_keywords',date='$date' where id_produk='$_GET[id_produk]' ");
   
   }
   
   if($update_product){
   
   echo "<script>alert('Product was updated successfully!')</script>";
   
   echo "<script>window.open(window.location.href,'_self')</script>";
   }
   
   }
?>








