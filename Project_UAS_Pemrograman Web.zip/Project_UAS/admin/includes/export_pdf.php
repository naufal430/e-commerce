<?php 
include('../../includes/db.php');
?>

<div class="view_product_box">

<h2>Lihat Produk</h2>
<div class="border_bottom"></div>

<form action="" method="post" enctype="multipart/form-data" />


<table width="100%">
 <thead>
  <tr>
   <th>ID</th>
   <th>Judul</th>
   <th>Harga</th>
   <th>Image</th>
   <th>Views</th>
   <th>Date</th>
   <th>Status</th>
  </tr>
 </thead>

 
 <?php 
 $all_products = mysqli_query($conn,"select * from produk order by id_produk DESC ");
 
 $i = 1;
 
 while($row=mysqli_fetch_array($all_products)){
 ?>
 
 <tbody>
  <tr>
   <td><input type="checkbox" name="deleteAll[]" value="<?php echo $row['id_produk'];?>" /></td>
   <td><?php echo $i; ?></td>
   <td><?php echo $row['judul_produk']; ?></td>
   <td><?php echo $row['harga_produk']; ?></td>
   <td><img src="../images_produk/<?php echo $row['image_produk']; ?>" width="70" height="50" /></td>
   <td><?php echo $row['views']; ?></td>
   <td><?php echo $row['date']; ?></td>
   <td>
   <?php 
   if($row['visible'] == 1){
    echo "Approved";
   }else{
    echo "Pending";
   }
   ?>
   </td>
  </tr>
 </tbody>
 
 <?php $i++;}?>
 
<tr>
</tr> 
</table>

</form>

</div>

<script>
  window.print();
  </script>

<?php