<?php 
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Produk.xls");
?>

<table border="1">
    
    <tr>
        <th>No</th>
        <th>Nama Produk</th>
        <th>Harga Produk</th>
        <th>Desc Produk</th>
    </tr>

    <?php
        $conn = mysqli_connect("localhost","root","","db_project_uts");
        $no = 1;
        $data = mysqli_query($conn,"select * from produk");

        while($d = mysqli_fetch_array($data)){
    ?>    
}
    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $d['judul_produk'];?></td>
        <td><?php echo $d['harga_produk'];?></td>
        <td><?php echo $d['desc_produk'];?></td>
    </tr>
    <?php
        }
    ?>

</table>
