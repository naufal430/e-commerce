<div class="delete_account_container">
    <h1 style="text-align:left">Konfirmasi</h1>
    <hr/>

    <div class="delete_account_box">
        <h4>Anda yakin ingin menghapus akun anda?</h4>
        <form action="" method="post">
            <input type="submit" class="yes_btn" name="yes" value="Yes"/>
            <input type="submit" name="cancel" value="Cancel"/>
        </form>
    </div>

</div>

<?php

if (isset($_POST['yes'])) {
    $delete_account = mysqli_query($conn,"DELETE FROM users WHERE id='$_SESSION[user_id]' ");
    session_destroy();
    echo "<script>alert('Akun Anda Terhapus! ')</script>";
    echo "<script>window.open('index.php','_self')</script>";
   
}

if (isset($_POST['cancel'])){
    echo "<script>window.open(window.location.href,'_self')</script>";
}

?>