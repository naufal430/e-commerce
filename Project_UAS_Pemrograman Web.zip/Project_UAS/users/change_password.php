<script>
    $(document).ready(function() {
        $("#password_confirm2").on('keyup',function() {
            var password_confirm1 = $("#password_confirm1").val();
            var password_confirm2 = $("#password_confirm2").val();

            if (password_confirm1 == password_confirm2) {
                $("#status_for_confirm_password").html('<strong style="color:green">Password match</strong>');
            } else {
                $("#status_for_confirm_password").html('<strong style="color:red">Password do not match</strong>');
            }
        });
    });
</script>

<?php

$select_user = mysqli_query($conn,"SELECT * FROM users WHERE id='$_SESSION[user_id]' ");
$fetch_user = mysqli_fetch_array($select_user);

?>

<div class="register-box">
    <form method="post" action="" enctype="multipart/form-data">
        <table>
            <tr>
                <td>
                    <h2>Ganti Password.</h2>
                    <br/>
                </td>
            </tr>
            <tr>
                <td><h2>Password Lama:</h2></td>
                <td><input type="password" name="current_password" required placeholder="Current Password"/></td>
            </tr>
            <tr>
                <td><h2>Password Baru:</h2></td>
                <td><input type="password" id="password_confirm1" name="new_password" required placeholder="New Password"/></td>
            </tr>
            <tr>
                <td><h2>Konfirmasi Password Baru:</h2></td>
                <td>
                    <input type="password" id="password_confirm2" name="confirm_new_password" required placeholder="Re-Type New Password"/>
                    <p id="status_for_confirm_password"></p>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" name="change_password" value="Save"/>
                </td>
            </tr>
        </table>
    </form>
</div>

<?php

if (isset($_POST['change_password'])) {
    $current_password = trim($_POST['current_password']);
    $hash_current_password = md5($current_password);
   
    $new_password = trim($_POST['new_password']);
    $hash_new_password = md5($new_password);
    $connfirm_new_password = trim($_POST['confirm_new_password']);
  
    $select_password = mysqli_query($conn,"SELECT * FROM users WHERE password='$hash_current_password' AND id='$_SESSION[user_id]' ");

    if (mysqli_num_rows($select_password) == 0) {
        echo "<script>alert('Password Lama anda Salah!')</script>";
    } elseif ($new_password != $connfirm_new_password) {
        echo "<script>alert('Password tidak sama!')</script>";
    } else {
        $update = mysqli_query($conn,"UPDATE users SET password='$hash_new_password' WHERE id='$_SESSION[user_id]' ");

        if ($update) {
            echo "<script>alert('Password Anda Berhasil Diubah!')</script>";
	        echo "<script>window.open(window.location.href,'_self')</script>";
        } else {
            echo "<script>alert('Database query failed: mysqli_error($conn) !')</script>";
        }
    }
}

?>