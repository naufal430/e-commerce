<?php 

$select_user = mysqli_query($conn,"SELECT * FROM users WHERE id='$_SESSION[user_id]' ");
$fetch_user = mysqli_fetch_array($select_user);

?>
	
<div class="register-box">
    <form method = "post" action="" enctype="multipart/form-data">
	    <table>
	        <tr>	   
	            <td>
                    <h2>Foto Profil User.</h2>
                    <br/>
	            </td>	   
	        </tr>	  
	        <tr>
	            <td><h2>Image:</h2></td>
	            <td>
                    <input type="file" name="image"/>
                    <div>
                        <img src="uploaded-files/<?php echo $fetch_user['image']; ?>" width="100" height="70" />
                    </div>
                </td>
	        </tr>	  
	        <tr>
	            <td></td>
	            <td>
	                <input type="submit" name="user_profile_picture" value="Save"/>
	            </td>
	        </tr>
        </table>
    </form>
</div>

<?php

if (isset($_POST['user_profile_picture'])) {  
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];   
        $target_file = "uploaded-files/" . $image;   
        $uploadOk = 1;
        $message = '';
   
        if ($_FILES["image"]["size"] < 5098888) {
            if (file_exists($target_file)) {
                $uploadOk = 0;
	            $message .=" Maaf, file sudah ada. ";
	
            }

            if ($uploadOk == 0) {
                $message .="Maaf, file anda tidak terunggah . ";
            } else {
                if (move_uploaded_file($image_tmp, $target_file)) {
	                $update_image = mysqli_query($conn,"update users set image='$image' where id='$_SESSION[user_id]'");
	                $message .= "File" . basename($image) . " telah terunggah. ";
	            } else {
	                $message .= "Maaf, ada kesalahan dalam menunggah file anda. ";
	            }
            }
        } else {
            $message .= "Ukuran maksimal File adalah 5 MB. ";
        }
    }
}

?>

<p style="color:green;margin-left:15px">
    <?php if(isset($message)){echo $message;} ?>
</p>