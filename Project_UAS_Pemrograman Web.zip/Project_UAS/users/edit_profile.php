<?php 

$select_user = mysqli_query($conn,"SELECT * FROM users WHERE id='$_SESSION[user_id]' ");
$fetch_user = mysqli_fetch_array($select_user);

?>

<div class="register_box">
    <form method = "post" action="" enctype="multipart/form-data">
	    <table>
	        <tr>	   
	            <td>
	                <h2>Edit Profile.</h2><br />
	            </td>	   
	        </tr>
	        <tr>
	            <td><b>Ganti Nama:</b></td>
	            <td><input type="text" name="name" value="<?php echo $fetch_user['name'];?>" required placeholder="Name"/></td>
	        </tr>	 
	        <tr>
	            <td><b>Nomor Telephone:</b></td>
	            <td><input type="text" name="notel" value="<?php echo $fetch_user['notel'];?>" required placeholder="No Telephone"/></td>
	        </tr>
	        <tr>
	            <td></td>
	            <td>
	                <input type="submit" name="edit_profile" value="Save"/>
	            </td>
	        </tr>
	    </table>
    </form>
</div>

<?php

if (isset($_POST['edit_profile'])) {  
    if($_POST['name'] !='' && $_POST['notel'] !='' ) {
        $name = $_POST['name'];
        $notel = $_POST['notel'];
  
        $update_profile = mysqli_query($conn,"UPDATE users SET name='$name', notel='$notel' WHERE id='$_SESSION[user_id]'");
   
        if ($update_profile) {
            echo "<script>alert('Update Profil Berhasil!')</script>";
            echo "<script>window.open(window.location.href,'_self')</script>";
        }
    }
}

?>